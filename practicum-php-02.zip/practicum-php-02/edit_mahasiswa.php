<?php
$conn = new mysqli("localhost", "root", "", "int_prog");

$nim = $_GET['nim'];
$result = $conn->query("SELECT * FROM data_mahasiswa WHERE nim=$nim");
$data_mhs = $result->fetch_assoc();
?>

<form action="edit_mahasiswa_process.php" method="POST">
  <label>Nama Mahasiswa:</label><br>
  <input type="text" name="nama" value="<?= $data_mhs['nama']; ?>"><br>

  <br>
  <label>Email:</label><br>
  <input type="email" name="email" value="<?= $data_mhs['email']; ?>"><br>

  <input type="hidden" name="nim" value="<?= $data_mhs['nim']; ?>"> <br>
  <button type="submit">Update</button>
</form>
