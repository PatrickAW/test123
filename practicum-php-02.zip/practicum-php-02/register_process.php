<?php
$servername = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "int_prog";

$conn = new mysqli($servername, $dbuser, $dbpass, $dbname);

if ($conn->connect_error) {
  die("Koneksi gagal: " . $conn->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];
$password2 = $_POST['password2'];

if ($password === $password2) {
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users(username, password) VALUES ('$username', '$password_hash')";
    if ($conn->query($sql) === TRUE) {
        header("Location: login.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
} else {
    echo "Password tidak sama! <a href='register.php'>Kembali</a>";
}
$conn->close();
?>
