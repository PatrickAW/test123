<?php
$nim = $_GET['nim'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Edit Data Mahasiswa</h2>
        <p>NIM: <?= $nim; ?></p>
        <a href="index.php">Kembali ke Daftar Mahasiswa</a>
    </div>
</body>
</html>
