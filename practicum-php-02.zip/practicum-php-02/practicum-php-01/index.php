<?php
$data_mahasiswa = [
    ["nama" => "Nicholas Rafael", "nim" => "24.K1.0010", "email" => "24k10010@student.unika.ac.id", "active" => true],
    ["nama" => "Patrick", "nim" => "24.K1.0018", "email" => "24k10018@student.unika.ac.id", "active" => false],
    ["nama" => "Nabil", "nim" => "24.K1.0047", "email" => "24k10047@student.unika.ac.id", "active" => true],
    ["nama" => "Riski", "nim" => "24.K1.0066", "email" => "24k10066@student.unika.ac.id", "active" => true],
    ["nama" => "Christopher", "nim" => "24.K1.0016", "email" => "24k10016@student.unika.ac.id", "active" => true],
    ["nama" => "Dhimas", "nim" => "24.K1.0030", "email" => "24k10030@student.unika.ac.id", "active" => true],
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Data Mahasiswa</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h2>Data Mahasiswa</h2>
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>NIM</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1;
                foreach ($data_mahasiswa as $index => $mhs) : 
                    $row_class = "";
                    if ($index % 2 == 1) {
                        $row_class = "gray";
                    }
                    if (!$mhs['active']) {
                        $row_class = "alert"; 
                    }
                ?>
                <tr class="<?= $row_class; ?>">
                    <td><?= $no++; ?></td>
                    <td><?= $mhs['nama']; ?></td>
                    <td><?= $mhs['nim']; ?></td>
                    <td><?= $mhs['email']; ?></td>
                    <td>
                        <a href="edit_mahasiswa.php?nim=<?= $mhs['nim']; ?>">Edit</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
