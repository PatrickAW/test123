<h2>Reset Password</h2>

<form action="lupa_password_process.php" method="POST">
  <label>Username:</label><br>
  <input type="text" name="username" required><br>

  <br>
  <label>Password Baru:</label><br>
  <input type="password" name="new_password" required><br>
  
  <br>
  <label>Ulangi Password:</label><br>
  <input type="password" name="confirm_password" required><br>
  
  <br>
  <button type="submit">Ubah Password</button>
</form>

<p><a href="login.php">Kembali ke Login</a></p>
