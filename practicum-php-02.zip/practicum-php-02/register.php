<h1>Form Register</h1>
<form action="register_process.php" method="POST">
  <label>Username:</label><br>
  <input type="text" name="username" required><br>

  <label>Password:</label><br>
  <input type="password" name="password" required><br>

  <label>Confirm Password:</label><br>
  <input type="password" name="password2" required><br>
  <br>
  <button type="submit">Register</button>
</form>
