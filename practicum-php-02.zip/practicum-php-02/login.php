<h1>Form Login</h1>
<form action="login_process.php" method="POST">
  <label>Username:</label><br>
  <input type="text" name="username" required><br>

  <label>Password:</label><br>
  <input type="password" name="password" required><br>

  <br>
  <button type="submit">Login</button>
</form>

<p><a href="lupa_password.php">Lupa Password?</a></p>