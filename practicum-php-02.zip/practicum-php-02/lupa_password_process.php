<?php
$conn = new mysqli("localhost", "root", "", "int_prog");

$username = $_POST['username'];
$new_password = $_POST['new_password'];
$confirm_password = $_POST['confirm_password'];

if ($new_password === $confirm_password) {
    $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
    $sql = "UPDATE users SET password='$new_hash' WHERE username='$username'";
    if ($conn->query($sql) === TRUE) {
        echo "Password berhasil diubah! <a href='login.php'>Login Sekarang</a>";
    } else {
        echo "Terjadi kesalahan: " . $conn->error;
    }
} else {
    echo "Password tidak sama! <a href='forgot_password.php'>Coba lagi</a>";
}
$conn->close();
?>
