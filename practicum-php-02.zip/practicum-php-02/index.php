<?php
$conn = new mysqli("localhost", "root", "", "int_prog");

$users = $conn->query("SELECT * FROM users");
$data_mhs = $conn->query("SELECT * FROM data_mahasiswa");
?>

<h2>Daftar Pengguna</h2>
<table border="1">
<tr><th>Username</th><th>Delete</th></tr>
<?php while($u = $users->fetch_assoc()): ?>
<tr>
  <td><?= $u['username']; ?></td>
  <td><a href="delete_user.php?username=<?= $u['username']; ?>">Delete</a></td>
</tr>
<?php endwhile; ?>
</table>

<h2>Data Mahasiswa</h2>
<table border="1">
<tr><th>NIM</th><th>Nama</th><th>Email</th><th>Edit</th></tr>
<?php while($m = $data_mhs->fetch_assoc()): ?>
<tr>
  <td><?= $m['nim']; ?></td>
  <td><?= $m['nama']; ?></td>
  <td><?= $m['email']; ?></td>
  <td><a href="edit_mahasiswa.php?nim=<?= $m['nim']; ?>">Edit</a></td>
</tr>
<?php endwhile; ?>
</table>
