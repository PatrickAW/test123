<?php
$conn = new mysqli("localhost", "root", "", "int_prog");

$username = $_GET['username'];
$sql = "DELETE FROM users WHERE username='$username'";
$conn->query($sql);

header("Location: index.php");
exit();
?>
