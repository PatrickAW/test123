<?php
$servername = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "int_prog";

$conn = new mysqli($servername, $dbuser, $dbpass, $dbname);

$username = $_POST['username'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE username='$username'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password'])) {
        header("Location: index.php");
        exit();
    } else {
        echo "Password salah! <a href='login.php'>Kembali</a>";
        exit();
    }
} else {
    header("Location: login.php");
    exit();
}
$conn->close();
?>
