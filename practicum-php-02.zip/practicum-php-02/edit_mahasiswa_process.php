<?php
$conn = new mysqli("localhost", "root", "", "int_prog");

$nama = $_POST['nama'];
$email = $_POST['email'];
$nim = $_POST['nim'];

$sql = "UPDATE data_mahasiswa SET nama='$nama', email='$email' WHERE nim=$nim";
$conn->query($sql);

header("Location: index.php");
exit();
?>
